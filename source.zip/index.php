<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5a12f3a02             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\162\x5f\165\x74\x69\154\151\x74\171\137\144\x6f\x63\x75\155\145\x6e\164\137\147\x65\x74\137\160\x64\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
