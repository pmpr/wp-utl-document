<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d417dee3             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\x70\162\x5f\x75\x74\151\x6c\151\164\x79\x5f\x64\x6f\x63\x75\x6d\x65\x6e\x74\x5f\x67\145\x74\137\160\x64\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
