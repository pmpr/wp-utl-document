<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce113e51a4a             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\x70\x72\x5f\165\164\151\x6c\x69\x74\171\x5f\144\157\143\x75\155\x65\x6e\164\x5f\147\145\x74\137\x70\144\146")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
