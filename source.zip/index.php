<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a89f0372             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\x70\x72\x5f\x75\x74\x69\154\151\x74\x79\x5f\144\157\143\x75\x6d\145\156\x74\x5f\147\145\x74\x5f\x70\144\146")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
