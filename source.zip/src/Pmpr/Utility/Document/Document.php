<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb4829e927d             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\UtilityInitiator; class Document extends UtilityInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\104\x6f\143\x75\155\145\156\x74\40\x47\145\156\145\162\141\x74\x6f\x72", PR__CMN__FOUNDATION); }, self::wuowaiyouwecckaw => false]); } }
