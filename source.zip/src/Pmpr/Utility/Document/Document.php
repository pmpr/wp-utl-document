<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5a12f3a02             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\UtilityInitiator; class Document extends UtilityInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x44\157\143\165\x6d\x65\x6e\x74\40\x47\145\x6e\x65\x72\x61\164\x6f\162", PR__CMN__FOUNDATION); }, self::wuowaiyouwecckaw => false]); } }
