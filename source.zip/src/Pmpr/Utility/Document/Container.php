<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a89f0372             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\LightContainer; class Container extends LightContainer { }
