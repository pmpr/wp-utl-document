<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebdf93b24             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\LightContainer; class Container extends LightContainer { }
